package univ;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Results_prof extends JFrame{
	JPanel title_panel, input_panel, search_panel, button_panel;
	JLabel title, prof_code, prof_name, open_y, open_grade, open_semester;
	JTextField code_field, name_field, search_field;
	JComboBox combo, y_c, grade_c, semester_c;
	String menu[] = {"검색할 카테고리 선택하세요","code"};
	String gc[] = {"1학년","2학년","3학년","4학년"};
	String yc[] = {"2021","2022","2023","2024","2025","2026","2027","2028"};
	String s[] = {"1학기","2학기","3여름학기","4겨울학기"};
	JButton look_bt,add_bt,end_bt;
	JScrollPane table_panel;
	DefaultTableModel dtm;
	JTable table;
	Font fon1 = new Font("Dialog",Font.PLAIN,20);
	
	public Results_prof(){
		setTitle("성적 관리");
		setLayout(null);
		setBounds(50,50,600,650);
		title();
		input();
		search();
		table();
		button();
		
		setResizable(false);
		setVisible(true);
	}
	void title(){
		title_panel = new JPanel(null);
		title_panel.setBackground(Color.black);
		title = new JLabel("성적관리");
		title.setFont(fon1);
		title.setForeground(Color.white);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setBounds(5,5,600,30);
		title_panel.add(title);
		title_panel.setBounds(0,0,600,50);
		add(title_panel);
	}
	void input() {
		input_panel = new JPanel(null);
		
		prof_code = new JLabel("교수코드");
		prof_name = new JLabel("교수이름");
		open_y = new JLabel("개설년도");
		open_grade = new JLabel("개설학년");
		open_semester = new JLabel("개설학기");
		
		code_field = new JTextField();
		name_field = new JTextField();
		y_c = new JComboBox(yc);
		grade_c = new JComboBox(gc);
		semester_c = new JComboBox(s);
		
		input_panel.setBounds(0,50,600,170);
		
		prof_code.setBounds(15,20,60,25);
		code_field.setBounds(80,20,90,25);
		prof_name.setBounds(210,20,60,25);		
		name_field.setBounds(275,20,90,25);
		open_y.setBounds(405,20,60,25);
		y_c.setBounds(470,20,90,25);
		
		open_grade.setBounds(15,50,60,25);
		grade_c.setBounds(80,50,90,25);
		open_semester.setBounds(210,50,60,25);
		semester_c.setBounds(275,50,90,25);
		
		input_panel.add(prof_code);
		input_panel.add(prof_name);
		input_panel.add(open_y);
		input_panel.add(open_grade);
		input_panel.add(open_semester);
		
		input_panel.add(code_field);
		input_panel.add(name_field);
		input_panel.add(y_c);
		input_panel.add(grade_c);
		input_panel.add(semester_c);
		add(input_panel);
	}
	void search() {
		search_panel = new JPanel(null);
		combo = new JComboBox(menu);
		search_field = new JTextField();
		look_bt = new JButton("조회");
		
		search_panel.setBackground(Color.GRAY);
		look_bt.setBackground(Color.black);
		look_bt.setForeground(Color.white);
		
		search_panel.setBounds(0,220,600,50);
		combo.setBounds(10,10,170,30);
		search_field.setBounds(185,10,150,30);
		look_bt.setBounds(480,10,100,30);
		
		search_panel.add(combo);
		search_panel.add(search_field);
		search_panel.add(look_bt);
		
		add(search_panel);
	}
	void table() {
		String header[] = {"학번","이름","출석","레포트","중간","기말","가산점","합계","학점"};
		Object rowdata[][] = {};
		dtm = new DefaultTableModel(null, header);
		table = new JTable(dtm);
		table_panel = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		table.setAutoCreateRowSorter(true);
		table_panel.setBounds(5,275,575,230);
		
		add(table_panel);
	}
	void button() {
		button_panel = new JPanel(null);
		add_bt = new JButton("저장");
		end_bt = new JButton("종료");
		
		button_panel.setBounds(0,510,600,140);
		add_bt.setBounds(295,30,135,50);
		end_bt.setBounds(435,30,135,50);
		
		button_panel.add(add_bt);
		button_panel.add(end_bt);
		
		add(button_panel);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Results_prof();
	}

}
