package thurs1110;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class Addr extends JFrame implements ActionListener {
	JPanel PANEL_1,PANEL_2,PANEL_3,PANEL_4; //1타이틀 2입력 3조회 4테이블
	JLabel LABEL_TITLE, L_NAME, L_AGE,L_GENDER, L_ADDR, L_PHONE, L_PHONE2, L_PHONE3,
			L_EMAIL, L_DOT;
	JTextField JTP_name,JTP_age,JTP_gender,JTP_addr,JTP_phone,JTP_phone2,JTP_phone3,
				JTP_email,JTP_email2,JTP_dot, JTP_search;
	JRadioButton JRB_gender1,JRB_gender2;
	JComboBox JCbox,JCbox_search;
	JButton JB_search1, JB_all,
				JB_input,JB_modify,JB_del,JB_exit;
	String mail[] = {"nate.com","naver.com","gmail.com"};
	String search1[] = {"이름","나이","성별","주소","연락처","이메일","INDEX"};
	JTable table;
	JScrollPane jsp;
	DefaultTableModel dtm;
	ResultSet rs = null;
	PreparedStatement pstmt;
	Connect cq;
	int srow;
	int idx;
	String genderS;
	String n[] = {"name", "age", "gender", "addr", "phone", "email", "INDEX"};

	
	public Addr() {
		this.setTitle("자바 주소록 관리 프로그램");
		this.setLayout(null);
		this.setBounds(50,50,600,650);
		cq();
		Title();
		Input();
		Search();
		TableSet();
		ButtonTable();
		
		this.setResizable(false); 	// 메롱 ㅇㅠㅇ
		setVisible(true);
	}
	void Title() {
		PANEL_1 = new JPanel(null);
		PANEL_1.setBackground(Color.black);
		LABEL_TITLE = new JLabel("개발과정 주소록관리 프로그램컨벼젼스");
		LABEL_TITLE.setForeground(Color.white);
		LABEL_TITLE.setHorizontalAlignment(JLabel.CENTER);
		LABEL_TITLE.setBounds(5,5,600,30);
		PANEL_1.add(LABEL_TITLE);
		PANEL_1.setBounds(0,0,600,40);
		this.add(PANEL_1);
	}
	void Input() {
		PANEL_2 = new JPanel(null);
		PANEL_2.setBorder(new TitledBorder(new LineBorder(Color.black, 1), "입력"));
		PANEL_2.setBounds(0,40,580,160);
		L_NAME = new JLabel("이름");
		L_AGE = new JLabel("나이");
		L_GENDER = new JLabel("성별");
		L_ADDR = new JLabel("주소");
		L_PHONE = new JLabel("연락처");
		L_PHONE2 = new JLabel("-");
		L_PHONE3 = new JLabel("-");
		L_EMAIL = new JLabel("이메일");
		L_DOT = new JLabel("@");
		
		JTP_name = new JTextField();
		JTP_age = new JTextField();
		JTP_gender = new JTextField();
		JTP_addr = new JTextField();
		JTP_phone = new JTextField();
		JTP_phone2 = new JTextField();
		JTP_phone3 = new JTextField();
		JTP_email = new JTextField();
		JTP_dot = new JTextField();
		
		JRB_gender1 = new JRadioButton("남");
		JRB_gender2 = new JRadioButton("여");
		ButtonGroup bg = new ButtonGroup();
		JRB_gender1.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				Object c = e.getItem();
				genderS = JRB_gender1.getActionCommand();
			}
			
		});
		JRB_gender2.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				Object c = e.getItem();
				genderS = JRB_gender2.getActionCommand();
			}
			
		});
		
		
		bg.add(JRB_gender1);
		bg.add(JRB_gender2);
		
		JCbox = new JComboBox(mail);
		JCbox.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				Object a = e.getItem();
				JTP_dot.setText(String.valueOf(a));
			}
			
		});
		
		
		L_NAME.setBounds(25,20,40,25);
		L_AGE.setBounds(230,20,40,25);
		L_GENDER.setBounds(380,20,40,25);
		L_ADDR.setBounds(25,55,40,25);
		L_PHONE.setBounds(25,90,40,25);
		L_PHONE2.setBounds(225,90,5,25);
		L_PHONE3.setBounds(385,90,5,25);
		L_EMAIL.setBounds(25,125,40,25);
		L_DOT.setBounds(230,125,15,25);
		
		JTP_name.setBounds(75,20,140,25);
		JTP_age.setBounds(270,20,85,25);
		
		JRB_gender1.setBounds(425,20,45,25);
		JRB_gender2.setBounds(470,20,45,25);
		
		
		JTP_addr.setBounds(75,55,470,25);
		JTP_phone.setBounds(75,90,145,25);
		JTP_phone2.setBounds(235,90,145,25);
		JTP_phone3.setBounds(395,90,145,25);
		JTP_email.setBounds(75,125,150,25);
		JTP_dot.setBounds(250,125,150,25);
		
		JCbox.setBounds(405,125,135,25);
		
		PANEL_2.add(L_NAME);
		PANEL_2.add(L_AGE);
		PANEL_2.add(L_GENDER);
		PANEL_2.add(L_ADDR);
		PANEL_2.add(L_PHONE);
		PANEL_2.add(L_PHONE2);
		PANEL_2.add(L_PHONE3);
		PANEL_2.add(L_EMAIL);
		PANEL_2.add(L_DOT);
		
		PANEL_2.add(JTP_name);
		PANEL_2.add(JTP_age);
		PANEL_2.add(JTP_gender);
		PANEL_2.add(JTP_addr);
		PANEL_2.add(JTP_phone);
		PANEL_2.add(JTP_phone2);
		PANEL_2.add(JTP_phone3);
		PANEL_2.add(JTP_email);
		PANEL_2.add(JTP_dot);
		PANEL_2.add(JCbox);
		
		PANEL_2.add(JRB_gender1);
		PANEL_2.add(JRB_gender2);
		
		this.add(PANEL_2);
		
	}
	void Search() {
		PANEL_3 = new JPanel(null);
		JCbox_search = new JComboBox(search1);
		JCbox_search.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				Object s = e.getItem();
				
			}
			
		});
		JTP_search = new JTextField();
		JB_search1 = new JButton("검색");
		JB_all = new JButton("전체 검색");
		
		JB_all.addActionListener(this);
		JB_search1.addActionListener(this);
		
		PANEL_3.setBackground(Color.magenta);
		PANEL_3.setBounds(0,200,600,60);
		JCbox_search.setBounds(15,20,150,25);
		JTP_search.setBounds(175,20,150,25);
		JB_search1.setBounds(335,20,100,25);
		JB_all.setBounds(440,20,100,25);
		PANEL_3.add(JCbox_search);
		PANEL_3.add(JTP_search);
		PANEL_3.add(JB_search1);
		PANEL_3.add(JB_all);
		
		this.add(PANEL_3);		
	}
	void TableSet() {
		String colheader[] = {
				"이름","나이","성별","주소","연락처","이메일","INDEX"
		};
		Object rowdata[][] = {};
		dtm = new DefaultTableModel(null, colheader);
		table = new JTable(dtm);
		table.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				super.mouseClicked(e);
				srow = table.getSelectedRow();
				
				String name = ((String)table.getValueAt(srow, 0));
				JTP_name.setText(name);
				
				JTP_age.setText(table.getValueAt(srow, 1).toString());
				String gender = (String)table.getValueAt(srow, 2);
				JTP_addr.setText(table.getValueAt(srow, 3).toString());
				String phone = (String)table.getValueAt(srow, 4);
				
				String email = (String)table.getValueAt(srow, 5);
				idx = (int) table.getValueAt(srow, 6);
				
				JTP_phone.setText(phone.substring(0,3));
				JTP_phone2.setText(phone.substring(4,8));
				JTP_phone3.setText(phone.substring(9,13));
				
				JTP_email.setText(email.substring(0, email.indexOf("@")));
				JTP_dot.setText(email.substring(email.indexOf("@")+1));
				
				if(gender.equals("여")) {
					JRB_gender2.setSelected(true);
				}else {
					JRB_gender1.setSelected(true);
				}
			}
			
		});
		jsp = new JScrollPane(table);
		jsp.setBorder(new TitledBorder(new LineBorder(Color.black, 1), "테이블"));
		//jsp.setLayout(null);
		jsp.setBounds(5,270,580,270);
		
		this.add(jsp);
	}
	void ButtonTable() {
		PANEL_4 = new JPanel(null);
		PANEL_4.setBounds(0,545,600,55);
		JB_input = new JButton("입력");
		JB_modify = new JButton("수정");
		JB_del = new JButton("삭제");
		JB_exit = new JButton("종료");
		
		JB_input.addActionListener(this);
		JB_modify.addActionListener(this);
		JB_del.addActionListener(this);
		JB_exit.addActionListener(this);
		
		JB_input.setBounds(5,15,140,35);
		JB_modify.setBounds(150,15,140,35);
		JB_del.setBounds(295,15,140,35);
		JB_exit.setBounds(440,15,140,35);
		
		PANEL_4.add(JB_input);
		PANEL_4.add(JB_modify);
		PANEL_4.add(JB_del);
		PANEL_4.add(JB_exit);
		
		this.add(PANEL_4);
		
	}
	void cq() {
		cq = new Connect();
	}
	void getListAll() {
		try {
			this.dtm.setRowCount(0);
			
			String quary = "SELECT * FROM friend";
			pstmt = cq.conn.prepareStatement(quary);
			rs = pstmt.executeQuery(quary);
			while(rs.next()) {
				String name = rs.getString(1);
				String age = rs.getString(2);
				String gender = rs.getString(3);
				String addr = rs.getString(4);
				String phone = rs.getString(5);
				String email = rs.getString(6);
				idx = rs.getInt(7);
				
				Object[] rowData = {name, age,gender,addr,phone,email,idx};
				dtm.addRow(rowData);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==JB_modify) {
			update();
			
		}
		if(e.getSource()==JB_del) {
			del();
			getListAll();
		}
		if(e.getSource()==JB_search1) {
			searchM();
		}
		if(e.getSource()==JB_all) {
			getListAll();
		}
		if(e.getSource()==JB_input) {
			String name = JTP_name.getText();
			String age = JTP_age.getText();
			String gender = genderS;
			String addr = JTP_addr.getText();
			String phone1 = JTP_phone.getText();
			String phone2 = JTP_phone2.getText();
			String phone3 = JTP_phone3.getText();
			String phone = phone1 + "-" + phone2 + "-" + phone3;
			
			String email1 = JTP_email.getText();
			String email2 = JTP_dot.getText();
			String email = email1 + "@" + email2;
//			if(name.isEmpty()) {
//				JOptionPane.showMessageDialog(this, name);
//				JTP_name.requestFocus();
//				return;
//			}
//			if(age.isEmpty()) {
//				JOptionPane.showMessageDialog(this, age);
//				JTP_age.requestFocus();
//				return;
//			}
//			if(gender.isEmpty()) {
//				JOptionPane.showMessageDialog(this, gender);
//				JTP_gender.requestFocus();
//				return;
//			}
//			if(addr.isEmpty()) {
//				JOptionPane.showMessageDialog(this, addr);
//				JTP_addr.requestFocus();
//				return;
//			}
//			if(phone.isEmpty()) {
//				JOptionPane.showMessageDialog(this, phone);
//				JTP_phone.requestFocus();
//				return;
//			}
//			if(email.isEmpty()) {
//				JOptionPane.showMessageDialog(this, email);
//				JTP_email.requestFocus();
//				return;
//			}	
				String[] nag = {name,age,gender,addr,phone,email};
				
				int result = regist(name,age,gender,addr,phone,email);
				System.out.println("1");
				if(result != 0) {
					JOptionPane.showMessageDialog(getParent(), "등록성공");
					
				}else {
					JOptionPane.showConfirmDialog(getParent(), "등록실패!");
				}
			
		}
		if(e.getSource()==JB_exit) {
			dispose();
		}
		
		
	}
	public int regist(String name, String age, String gender, String addr, String phone,
			String email) {
		int result = 0;
		String sql = "INSERT INTO friend(name, age, gender,addr, phone, email, idx) VALUES(?,?,?,?,?,?,?)";
		try {
			pstmt = cq.conn.prepareStatement(sql);
			
			pstmt.setString(1, name);
			pstmt.setString(2, age);
			pstmt.setString(3, gender);
			pstmt.setString(4, addr);
			pstmt.setString(5, phone);
			pstmt.setString(6, email);
			pstmt.setInt(7, 0);
			result = pstmt.executeUpdate();
			
			getListAll();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	void searchM() {
		String info = n[JCbox_search.getSelectedIndex()];
		String sql = "SELECT * FROM friend WHERE " + info + " = '" + JTP_search.getText() + "'";
		
		try {
			pstmt = cq.conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			dtm.setRowCount(0);
			while(rs.next()) {
				String name = rs.getString(1);
				String age = rs.getString(2);
				String gender = rs.getString(3);
				String addr = rs.getString(4);
				String phone = rs.getString(5);
				String email = rs.getString(6);
				int idx = rs.getInt(7);
				
				Object[] rowData = {name, age,gender,addr,phone,email,idx};
				
				dtm.addRow(rowData);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	void del() {
		String sql = "DELETE FROM friend where idx = ?";
		int a = 0;
		System.out.println("삭제혀");
		try {
			pstmt = cq.conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			
			a = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void update() {
		String sql1 = "update friend set name = ?, age=?,gender=?,addr=?,phone=?,email=? where idx = ?";
		
		String phone1 = JTP_phone.getText();
		String phone2 = JTP_phone2.getText();
		String phone3 = JTP_phone3.getText();
		String phone = phone1 + "-" + phone2 + "-" + phone3;
		
		String email1 = JTP_email.getText();
		String email2 = JTP_dot.getText();
		String email = email1 + "@" + email2;
		
		try {
			pstmt = cq.conn.prepareStatement(sql1);
			
			pstmt.setString(1, JTP_name.getText());
			pstmt.setString(2, JTP_age.getText());
			pstmt.setString(3, genderS);
			pstmt.setString(4, JTP_addr.getText());
			pstmt.setString(5, phone);
			pstmt.setString(6, email);
			pstmt.setInt(7, idx);
			
			int a = pstmt.executeUpdate();
			
			if(a != 0) {
				JOptionPane.showMessageDialog(getParent(), "수정성공");
				getListAll();
			}else {
				JOptionPane.showConfirmDialog(getParent(), "수정실패!");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Addr();
	}

}


