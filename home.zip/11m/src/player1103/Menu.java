package player1103;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class Menu extends JFrame implements ActionListener {
	JPanel titlepanel, textpanel, btnpanel;
	JLabel title, id, pass, username;
	JTextField idtext, passtext, nametext;
	JButton jbt, bt_modify, bt_del, bt_search, bt_exit,BT_Add;
	Font fon1;
	// fon1 = new Font("serif", Font.BOLD,20);
	// title.setFont(fon1);
	Inputtable intable;
	Search sear;
	Modify mod;
	PlayerDel pdel;
	
	
	public Menu() {
		this.setTitle("사용자"); // + username
		this.setLayout(null);
		this.setBounds(0, 0, 600, 650);

		Title();
		Button();

		setSize(600, 650);
		setVisible(true);

	}

	void Title() {
		titlepanel = new JPanel();
		fon1 = new Font("serif", Font.BOLD,20);
		titlepanel.setBackground(Color.black);
		titlepanel.setBounds(0, 0, 600, 40);
		title = new JLabel("K_League_Player");
		title.setFont(fon1);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setForeground(Color.white);
		title.setBounds(0, 0, 600, 40);
		titlepanel.add(title);
		this.add(titlepanel);
	}

	void Button() {
		btnpanel = new JPanel();
		btnpanel.setBorder(new TitledBorder(new LineBorder(Color.black, 2), "메뉴선택"));
		btnpanel.setLayout(null);
		btnpanel.setBounds(45, 45, 500, 550);
		jbt = new JButton("선수추가");
		jbt.setForeground(Color.yellow);
		jbt.setBackground(Color.blue);
		jbt.setBounds(100, 50, 240, 50);
		jbt.addActionListener(this);

		bt_modify = new JButton("선수수정");
		bt_modify.setForeground(Color.black);
		bt_modify.setBackground(Color.yellow);
		bt_modify.setBounds(100, 150, 240, 50);
		bt_modify.addActionListener(this);
		
		bt_del = new JButton("선수삭제");
		bt_del.setForeground(Color.red);
		bt_del.setBackground(Color.CYAN);
		bt_del.setBounds(100, 250, 240, 50);
		bt_del.addActionListener(this);
		
		bt_search = new JButton("선수검색");
		bt_search.setForeground(Color.red);
		bt_search.setBackground(Color.green);
		bt_search.setBounds(100, 350, 240, 50);
		bt_search.addActionListener(this);
		
		bt_exit = new JButton("종 료");
		bt_exit.setForeground(Color.white);
		bt_exit.setBackground(Color.MAGENTA);
		bt_exit.setBounds(100, 450, 240, 50);
		bt_exit.addActionListener(this);
		
		btnpanel.add(jbt);
		btnpanel.add(bt_modify);
		btnpanel.add(bt_del);
		btnpanel.add(bt_search);
		btnpanel.add(bt_exit);
		this.add(btnpanel);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==jbt) {
			intable = new Inputtable();
			dispose();
		}else if(e.getSource()==bt_modify) {
			mod = new Modify();
			dispose();
		}else if(e.getSource()==bt_del) {
			pdel = new PlayerDel();
			dispose();
		}else if(e.getSource()==bt_search) {
			sear = new Search();
		}else if(e.getSource()==bt_exit) {
			dispose();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Menu();
	}

}
