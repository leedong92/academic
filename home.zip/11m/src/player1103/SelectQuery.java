package player1103;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;

public class SelectQuery{
	JFrame jf;
	ResultSet rs = null;
	Statement stmt;
	ConQuery connect = new ConQuery();
	
	SelectQuery(Inputtable jf) throws SQLException{
		this.jf=jf;
		stmt = connect.conn.createStatement();
		String sql = "SELECT * FROM custome";
		rs = stmt.executeQuery(sql);

		while (rs.next()) {
			String name = rs.getString(1);
			String grade = rs.getString(2);
			String age = rs.getString(3);
			String job = rs.getString(4);
			System.out.println(name+" "+grade+" "+age+" "+job);
//			String dept_no = rs.getString(1);
//			String dept_name = rs.getString(2);
//			System.out.println(dept_no + "  " + dept_name);
		}
	}

//	public static void main(String[] args) throws SQLException{
//		// TODO Auto-generated method stub
//		new SelectQuery();
//
//	}

}
