package player1103;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Search extends JFrame implements ActionListener{
	JPanel titlepanel,textpanel,btnpanel;
	JLabel title,name;
	JTextField nametext;
	JButton search,allsearch,main;
	JTable table;
	JScrollPane jsp;
	DefaultTableModel dtm;
	Font fon1;
	// fon1 = new Font("serif", Font.BOLD,20);
	// title.setFont(fon1);
	ResultSet rs = null;
	PreparedStatement pstmt;
	ConQuery cq;
	
	public Search() {
		this.setTitle("K_League_Player");
		this.setLayout(null);
		this.setBounds(0,0,600,650);
		cq = new ConQuery();
		Title();
		Text();
		Table();
		Button();
		
		setSize(600,650);
		setVisible(true);
		
	}
	void Title() {
		titlepanel = new JPanel();
		fon1 = new Font("serif", Font.BOLD,20);
		titlepanel.setBackground(Color.black);
		titlepanel.setBounds(0,0,600,40);
		title = new JLabel("K_League_Player 선수 검색");
		title.setFont(fon1);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setForeground(Color.white);
		title.setBounds(0,0,600,40);
		titlepanel.add(title);
		this.add(titlepanel);
	}
	void Text() {
		textpanel = new JPanel();
		
		textpanel.setLayout(null);
		textpanel.setBounds(0,45,600,120);
		
		name = new JLabel("이름");
		name.setBounds(20,30,70,25);
		
		nametext = new JTextField();
		nametext.setBounds(100,30,130,25);
		
		allsearch = new JButton("전체검색");
		allsearch.setBounds(450,30,100,35);
		allsearch.setBackground(Color.cyan);
		allsearch.setForeground(Color.red);
		allsearch.addActionListener(this);
		
		search = new JButton("검색");
		search.setBounds(350,30,80,35);
		search.setBackground(Color.cyan);
		search.setForeground(Color.red);
		search.addActionListener(this);
		
		
		textpanel.add(name);
		textpanel.add(nametext);
		textpanel.add(allsearch);
		textpanel.add(search);
		
		this.add(textpanel);
	}
	void Table() {
		String colheader[] = {
				"번호","이름","나이","몸무게","포지션","등번호","연고지"
		};
		Object rowdata[][] = {};
		dtm = new DefaultTableModel(rowdata, colheader);
		table = new JTable(dtm);
		jsp = new JScrollPane(table);
		//jsp.setLayout(null);
		jsp.setBounds(5,170,570,300);
		
		this.add(jsp);
	}
	void Button() {
		btnpanel = new JPanel();
		btnpanel.setLayout(null);
		btnpanel.setBounds(0,470,600,180);
		
		main = new JButton("메인 메뉴");
		main.setBounds(50,50,100,40);
		main.setBackground(Color.blue);
		main.setForeground(Color.yellow);
		main.addActionListener(this);
		
		btnpanel.add(main);
		
		this.add(btnpanel);
	}
	void getListAll(){
		try {
			this.dtm.setRowCount(0);
			
			String quary = "SELECT * FROM player";
			pstmt = cq.conn.prepareStatement(quary);
			rs = pstmt.executeQuery(quary);
			while(rs.next()) {
				int idx = rs.getInt(1);
				String name1 = rs.getString(2);
				String age1 = rs.getString(3);
				String kg1 = rs.getString(4);
				String position1 = rs.getString(5);
				String backnum1 = rs.getString(6);
				String home1 = rs.getString(7);
				
				Object[] rowData = {idx, name1,age1,kg1,position1,backnum1,home1};
				dtm.addRow(rowData);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	void ss() {
		String query = "SELECT * FROM player where name = ?";
		this.dtm.setRowCount(0);
		try {
			pstmt = cq.conn.prepareStatement(query);
			pstmt.setString(1, nametext.getText());
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String idx = rs.getString(1);
				String name = rs.getString(2);
				String age = rs.getString(3);
				String kg = rs.getString(4);
				String position = rs.getString(5);
				String backnum = rs.getString(6);
				String hometown = rs.getString(7);
				
				Object[] rowData = {idx, name, age, kg, position, backnum, hometown};
				
				dtm.addRow(rowData);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==main) {
			Menu mn = new Menu();
			dispose();
		}
		if(e.getSource()==search) {
			ss();
			
		}
		if(e.getSource()==allsearch) {
			getListAll();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Search();
	}

}
