package player1103;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Login extends JFrame implements ActionListener {
	JPanel titlepanel, textpanel, btnpanel;
	JLabel title, id, pass, username;
	JTextField idtext, passtext, nametext;
	JButton jbt;
	Font fon1;
	ConQuery cq1;
	ResultSet rs = null;
	PreparedStatement stmt;
	Menu mn;

	public Login() {
		this.setTitle("로그인");
		this.setLayout(null);
		this.setBounds(0, 0, 600, 650);

		cq();
		Title();
		Text();
		Button();

		setSize(600, 650);
		setVisible(true);

	}

	void cq() { // db연결
		cq1 = new ConQuery();
	}

	void Title() {
		titlepanel = new JPanel();
		fon1 = new Font("serif", Font.BOLD, 20);
		titlepanel.setBackground(Color.black);
		titlepanel.setBounds(0, 0, 600, 40);
		title = new JLabel("로그인");
		title.setFont(fon1);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setForeground(Color.white);
		title.setBounds(0, 0, 600, 40);
		titlepanel.add(title);
		this.add(titlepanel);
	}

	void Text() {
		textpanel = new JPanel();
		id = new JLabel("아이디");
		pass = new JLabel("패스워드");
		username = new JLabel("사용자이름");
		idtext = new JTextField();
		passtext = new JTextField();
		nametext = new JTextField();
		textpanel.setLayout(null);
		textpanel.setBounds(0, 45, 600, 200);
		id.setBounds(10, 30, 50, 25);
		pass.setBounds(165, 30, 50, 25);
		username.setBounds(315, 30, 70, 25);
		idtext.setBounds(65, 30, 80, 25);
		passtext.setBounds(225, 30, 80, 25);
		nametext.setBounds(390, 30, 80, 25);
		textpanel.add(id);
		textpanel.add(pass);
		textpanel.add(username);
		textpanel.add(idtext);
		textpanel.add(passtext);
		textpanel.add(nametext);

		this.add(textpanel);
	}

	void Button() {
		btnpanel = new JPanel();
		btnpanel.setLayout(null);
		btnpanel.setBounds(0, 250, 600, 70);
		btnpanel.setBackground(Color.blue);

		jbt = new JButton("확인");
		jbt.setForeground(Color.red);
		jbt.setBackground(Color.green);
		jbt.setBounds(400, 15, 100, 40);

		jbt.addActionListener(this);

		btnpanel.add(jbt);
		this.add(btnpanel);

	}
	void mn() {
		mn = new Menu();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String id = null;
		String pass = null;
		String name = null;

		String sql = "SELECT * FROM admin where id = ? and pass = ?";
		if (e.getSource() == jbt) {
			try {
				stmt = cq1.conn.prepareStatement(sql);
				stmt.setString(1, idtext.getText());
				stmt.setString(2, passtext.getText());
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					id = rs.getString(1);
					pass = rs.getString(2);
					name = rs.getString(3);
				}

			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			if (idtext.getText().equals(id) && passtext.getText().equals(pass)) {
				nametext.setText(name);
				JOptionPane.showMessageDialog(null, name+"환영합니다");
				mn();
				dispose();
			} else {
				JOptionPane.showMessageDialog(this, "아이디/비밀번호가 다릅니다.", "조회",0);
				idtext.setText(null);
				passtext.setText(null);
				nametext.setText(null);
				
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Login();
	}

}
