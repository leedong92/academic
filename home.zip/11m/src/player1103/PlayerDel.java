package player1103;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PlayerDel extends JFrame implements ActionListener {
	JPanel titlepanel, textpanel, btnpanel;
	JLabel title, name;
	JTextField nametext;
	JButton del, main, player_del;
	JTable table;
	JScrollPane jsp;
	DefaultTableModel dtm;
	Font fon1;
	// fon1 = new Font("serif", Font.BOLD,20);
	// title.setFont(fon1);
	ResultSet rs = null;
	PreparedStatement pstmt;
	ConQuery cq;
	int idx;
	int srow;

	public PlayerDel() {
		this.setTitle("K_League_Player");
		this.setLayout(null);
		this.setBounds(0, 0, 600, 650);
		cq = new ConQuery();
		Title();
		Text();
		Table();
		getListAll();
		Button();

		setSize(600, 650);
		setVisible(true);

	}

	void Title() {
		titlepanel = new JPanel();
		fon1 = new Font("serif", Font.BOLD, 20);
		titlepanel.setBackground(Color.black);
		titlepanel.setBounds(0, 0, 600, 40);
		title = new JLabel("K_League_Player 선수 삭제");
		title.setFont(fon1);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setForeground(Color.white);
		title.setBounds(0, 0, 600, 40);
		titlepanel.add(title);
		this.add(titlepanel);
	}

	void Text() {
		textpanel = new JPanel();

		textpanel.setLayout(null);
		textpanel.setBounds(0, 45, 600, 120);

		name = new JLabel("이름");
		name.setBounds(20, 30, 70, 25);

		nametext = new JTextField();
		nametext.setBounds(100, 30, 130, 25);

		del = new JButton("삭제");
		del.setBounds(450, 30, 80, 35);
		del.setBackground(Color.cyan);
		del.setForeground(Color.red);

		textpanel.add(name);
		textpanel.add(nametext);
		textpanel.add(del);

		this.add(textpanel);
	}

	void Table() {
		String colheader[] = { "번호", "이름", "나이", "몸무게", "포지션", "등번호", "연고지" };
		Object rowdata[][] = {};
		dtm = new DefaultTableModel(rowdata, colheader);
		table = new JTable(dtm);
		jsp = new JScrollPane(table);
		// jsp.setLayout(null);
		jsp.setBounds(5, 170, 570, 300);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				srow = table.getSelectedRow();
				// idx = Integer.parseInt((String) table.getValueAt(srow, 0));
				idx = (int) table.getValueAt(srow, 0);
				String name = (String) table.getValueAt(srow, 1);
				String age = table.getValueAt(srow, 2).toString();
				String kg = table.getValueAt(srow, 3).toString();
				String position = table.getValueAt(srow, 4).toString();
				String backnum = table.getValueAt(srow, 5).toString();
				String hometown = table.getValueAt(srow, 6).toString();
				System.out.println(srow);
				nametext.setText(name);

			}

		});

		this.add(jsp);
	}

	void Button() {
		btnpanel = new JPanel();
		btnpanel.setLayout(null);
		btnpanel.setBounds(0, 470, 600, 180);

		main = new JButton("메인 메뉴");
		main.setBounds(170, 50, 100, 40);
		main.setBackground(Color.blue);
		main.setForeground(Color.yellow);
		main.addActionListener(this);

		player_del = new JButton("선수 삭제");
		player_del.setBounds(280, 50, 100, 40);
		player_del.setBackground(Color.yellow);
		player_del.setForeground(Color.black);
		player_del.addActionListener(this);

		btnpanel.add(main);
		btnpanel.add(player_del);

		this.add(btnpanel);
	}

	void getListAll() {
		try {
			this.dtm.setRowCount(0);

			String quary = "SELECT * FROM player";
			pstmt = cq.conn.prepareStatement(quary);
			rs = pstmt.executeQuery(quary);
			while (rs.next()) {
				int idx = rs.getInt(1);
				String name1 = rs.getString(2);
				String age1 = rs.getString(3);
				String kg1 = rs.getString(4);
				String position1 = rs.getString(5);
				String backnum1 = rs.getString(6);
				String home1 = rs.getString(7);

				Object[] rowData = { idx, name1, age1, kg1, position1, backnum1, home1 };
				dtm.addRow(rowData);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == main) {
			Menu mn = new Menu();
			dispose();
		}
		if (e.getSource() == player_del) {
			if (srow == -1) {
				JOptionPane.showMessageDialog(null, "삭제할 이름을 선택하세요");
				return;
			}
			String name = (String) dtm.getValueAt(srow, 1);
			int yn = JOptionPane.showConfirmDialog(null, name + "님을 삭제하시겠습니까", "이름", 0);

			if (yn == JOptionPane.YES_OPTION) {
				// ct2.dtm.removeRow(ct2.srow);
				int result = delete(name);
				if (result != 0) {
					getListAll();
				}
			} else {
				return;
			}
			JOptionPane.showMessageDialog(null, name + "님을 삭제하였습니다");
		}
	}

	public int delete(String name) {
		int result = 0;
		String quary = "DELETE FROM player WHERE name = ?";

		try {
			pstmt = cq.conn.prepareStatement(quary);
			pstmt.setString(1, name);
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new PlayerDel();
	}

}
