package player1103;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class Modify extends JFrame implements ActionListener {
	JPanel titlepanel, textpanel, btnpanel;
	JLabel title, name, age, kg, position, backnum, hometown;
	JTextField n_field, a_field, k_field, p_field, b_field, h_field;
	JButton bt_main, bt_add;
	JTable table;
	JScrollPane jsp;
	DefaultTableModel dtm;
	Font fon1;
	ConQuery cq;
	// Inputtable ipt = new Inputtable();
	// fon1 = new Font("serif", Font.BOLD,20);
	// title.setFont(fon1);
	ResultSet rs = null;
	PreparedStatement pstmt;
	Menu mn;
	int srow;
	int idx;

	public Modify() {
		this.setTitle("K_League_Player");
		this.setLayout(null);
		this.setBounds(0, 0, 600, 650);
		cq();

		Title();
		Text();
		Table();
		getListAll();
		Button();

		setSize(600, 650);
		setVisible(true);

	}

	void cq() {
		cq = new ConQuery();
	}

	void Title() {
		titlepanel = new JPanel();
		fon1 = new Font("serif", Font.BOLD, 20);
		titlepanel.setBackground(Color.black);
		titlepanel.setBounds(0, 0, 600, 40);
		title = new JLabel("K_League_Player 선수수정");
		title.setFont(fon1);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setForeground(Color.white);
		title.setBounds(0, 0, 600, 40);
		titlepanel.add(title);
		this.add(titlepanel);
	}

	void Text() {
		textpanel = new JPanel();
		textpanel.setLayout(null);
		textpanel.setBounds(5, 45, 570, 280);
		textpanel.setBorder(new TitledBorder(new LineBorder(Color.black, 1), "입력"));

		name = new JLabel("이름");
		name.setBounds(30, 30, 70, 25);
		n_field = new JTextField();
		n_field.setBounds(120, 30, 120, 25);

		age = new JLabel("나이");
		age.setBounds(30, 70, 70, 25);
		a_field = new JTextField();
		a_field.setBounds(120, 70, 120, 25);

		kg = new JLabel("몸무게");
		kg.setBounds(30, 110, 70, 25);
		k_field = new JTextField();
		k_field.setBounds(120, 110, 120, 25);

		position = new JLabel("포지션");
		position.setBounds(30, 150, 70, 25);
		p_field = new JTextField();
		p_field.setBounds(120, 150, 120, 25);

		backnum = new JLabel("등번호");
		backnum.setBounds(30, 190, 70, 25);
		b_field = new JTextField();
		b_field.setBounds(120, 190, 120, 25);

		hometown = new JLabel("연고지");
		hometown.setBounds(30, 230, 70, 25);
		h_field = new JTextField();
		h_field.setBounds(120, 230, 120, 25);

		textpanel.add(name);
		textpanel.add(n_field);
		textpanel.add(age);
		textpanel.add(a_field);
		textpanel.add(kg);
		textpanel.add(k_field);
		textpanel.add(position);
		textpanel.add(p_field);
		textpanel.add(backnum);
		textpanel.add(b_field);
		textpanel.add(hometown);
		textpanel.add(h_field);

		this.add(textpanel);
	}

	void Table() {
		String colheader[] = { "번호", "이름", "나이", "몸무게", "포지션", "등번호", "연고지" };
		Object rowdata[][] = {};
		dtm = new DefaultTableModel(rowdata, colheader);
		table = new JTable(dtm);
		jsp = new JScrollPane(table);
		// jsp.setLayout(null);
		jsp.setBounds(5, 330, 570, 200);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				srow = table.getSelectedRow();
				//idx = Integer.parseInt((String) table.getValueAt(srow, 0));
				idx = (int)table.getValueAt(srow, 0);
				String name = (String) table.getValueAt(srow, 1);
				String age = table.getValueAt(srow, 2).toString();
				String kg = table.getValueAt(srow, 3).toString();
				String position = table.getValueAt(srow, 4).toString();
				String backnum = table.getValueAt(srow, 5).toString();
				String hometown = table.getValueAt(srow, 6).toString();
				System.out.println(srow);
				n_field.setText(name);
				a_field.setText(age);
				k_field.setText(kg);
				p_field.setText(position);
				b_field.setText(backnum);
				h_field.setText(hometown);
			}

		});

		this.add(jsp);
	}

	void Button() {
		btnpanel = new JPanel();
		btnpanel.setLayout(null);
		btnpanel.setBounds(0, 500, 600, 100);

		bt_main = new JButton("메인메뉴");
		bt_main.setBounds(150, 50, 130, 50);
		bt_main.setForeground(Color.yellow);
		bt_main.setBackground(Color.blue);
		bt_main.addActionListener(this);

		bt_add = new JButton("수정");
		bt_add.setBounds(300, 50, 130, 50);
		bt_add.setForeground(Color.black);
		bt_add.setBackground(Color.yellow);
		bt_add.addActionListener(this);

		btnpanel.add(bt_main);
		btnpanel.add(bt_add);

		this.add(btnpanel);
	}

	void getListAll() {
		try {
			this.dtm.setRowCount(0);
			
			String quary = "SELECT * FROM player";
			pstmt = cq.conn.prepareStatement(quary);
			rs = pstmt.executeQuery(quary);
			while (rs.next()) {
				int idx = rs.getInt(1);
				String name1 = rs.getString(2);
				String age1 = rs.getString(3);
				String kg1 = rs.getString(4);
				String position1 = rs.getString(5);
				String backnum1 = rs.getString(6);
				String home1 = rs.getString(7);

				Object[] rowData = { idx, name1, age1, kg1, position1, backnum1, home1 };
				dtm.addRow(rowData);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	void mn() {
		mn = new Menu();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		cq = new ConQuery();
		if (e.getSource() == bt_add) {
			String name = n_field.getText();
			String age = a_field.getText();
			String kg = k_field.getText();
			String position = p_field.getText();
			String backnum = b_field.getText();
			String hometown = h_field.getText();
			System.out.println(name);
			int result = 0;
			
			String sql = "update player set name=?,age=?,kg=?,position=?,backnum=?,hometown=? where idx=?";
			try {
				
				pstmt = cq.conn.prepareStatement(sql);
				pstmt.setInt(7, idx);
				pstmt.setString(1, name);
				pstmt.setString(2, age);
				pstmt.setString(3, kg);
				pstmt.setString(4, position);
				pstmt.setString(5, backnum);
				pstmt.setString(6, hometown);
				int a = pstmt.executeUpdate();
				System.out.println(pstmt);

				if (a == 1) {
					JOptionPane.showMessageDialog(getParent(), "수정성공");
					getListAll();

				} else {
					JOptionPane.showConfirmDialog(getParent(), "수정실패!");
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		if(e.getSource()==bt_main) {
			mn = new Menu();
			dispose();
			
		}

	}

//	public int regist() {
//		int result = 0;
//		String sql = "update player set name=?,age=?,kg=?,position=?,backnum=?,hometown=? where idx=?";
//		try {
//			pstmt = ConQuery.conn.prepareStatement(sql);
//			pstmt.setInt(7, srow);
//			pstmt.setString(1, n_field.getText());
//			pstmt.setString(2, a_field.getText());
//			pstmt.setString(3, k_field.getText());
//			pstmt.setString(4, position.getText());
//			pstmt.setString(5, backnum.getText());
//			pstmt.setString(6, hometown.getText());
//			result = pstmt.executeUpdate();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return result;
//	}

//	@Override
//	public void mouseClicked(MouseEvent e) {
//		// TODO Auto-generated method stub
//		this.mouseClicked(e);
//		srow = table.getSelectedRow();
//		
//		int idx = Integer.parseInt((String) table.getValueAt(srow, 0));
//		String name = (String)table.getValueAt(srow, 1);
//		String age = table.getValueAt(srow, 2).toString();
//		String kg = table.getValueAt(srow, 3).toString();
//		String position = table.getValueAt(srow, 4).toString();
//		String backnum = table.getValueAt(srow, 5).toString();
//		String hometown = table.getValueAt(srow, 6).toString();
//		
//		n_field.setText(name);
//		a_field.setText(age);
//		k_field.setText(kg);
//		p_field.setText(position);
//		b_field.setText(backnum);
//		h_field.setText(hometown);
//	}
//	@Override
//	public void mousePressed(MouseEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//	@Override
//	public void mouseReleased(MouseEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//	@Override
//	public void mouseEntered(MouseEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//	@Override
//	public void mouseExited(MouseEvent e) {
//		// TODO Auto-generated method stub
//		
//	}
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		new Modify();
//	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Modify();
	}
}
