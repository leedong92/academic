package player1103;

import java.sql.*;

public class UpdateQuery {
	
	ResultSet rs = null;
	Statement stmt;
	ConQuery connect = new ConQuery();

	UpdateQuery() throws SQLException{
		stmt = connect.conn.createStatement();
		String sql = "SELECT dept_no,dept_name FROM departments";
		String str_up = "update departments set dept_name='오케이' where dept_no = 'd014'";
		
		try {
			int i = stmt.executeUpdate(str_up);
			if (i == 1) {
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					String dept_no = rs.getString(1);
					String dept_name = rs.getString(2);
					System.out.println(dept_no + "  " + dept_name);
				}
				System.out.println("레코드 업뎃 성공");

			} else
				System.out.println("레코드 업뎃 실패");

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("레코드 업뎃 실패");
		}
	}
	public static void main(String[] args) throws SQLException{
		// TODO Auto-generated method stub
		new UpdateQuery();

	}

}
