package player1103;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class Inputtable extends JFrame implements ActionListener{
	JPanel titlepanel,textpanel,btnpanel;
	JLabel title,name,age,kg,position,backnum,hometown;
	JTextField n_field,a_field,k_field,p_field,b_field,h_field;
	JButton bt_main, bt_add;
	JTable table;
	JScrollPane jsp;
	DefaultTableModel dtm;
	Font fon1;
	ConQuery cq;
	SelectQuery sq;
	Menu mn;
	// fon1 = new Font("serif", Font.BOLD,20);
	// title.setFont(fon1);
	ResultSet rs = null;
	PreparedStatement pstmt;
	
	public Inputtable() {
		this.setTitle("K_League_Player");
		this.setLayout(null);
		this.setBounds(0,0,600,650);
		cq();
		
		
		Title();
		Text();
		Table();
		getListAll();
		Button();
		
		setSize(600,650);
		setVisible(true);
		
	}
	void cq() {
		cq = new ConQuery();
	}
	void Title() {
		titlepanel = new JPanel();
		fon1 = new Font("serif", Font.BOLD,20);
		titlepanel.setBackground(Color.black);
		titlepanel.setBounds(0,0,600,40);
		title = new JLabel("K_League_Player 선수추가");
		title.setFont(fon1);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setForeground(Color.white);
		title.setBounds(0,0,600,40);
		titlepanel.add(title);
		this.add(titlepanel);
	}
	void Text() {
		textpanel = new JPanel();
		textpanel.setLayout(null);
		textpanel.setBounds(5,45,570,280);
		textpanel.setBorder(new TitledBorder(new LineBorder(Color.black,1),"입력"));
		
		name = new JLabel("이름");
		name.setBounds(30,30,70,25);
		n_field = new JTextField();
		n_field.setBounds(120,30,120,25);
		
		age = new JLabel("나이");
		age.setBounds(30,70,70,25);
		a_field = new JTextField();
		a_field.setBounds(120,70,120,25);
		
		kg = new JLabel("몸무게");
		kg.setBounds(30,110,70,25);
		k_field = new JTextField();
		k_field.setBounds(120,110,120,25);
		
		position = new JLabel("포지션");
		position.setBounds(30,150,70,25);
		p_field = new JTextField();
		p_field.setBounds(120,150,120,25);
		
		backnum = new JLabel("등번호");
		backnum.setBounds(30,190,70,25);
		b_field = new JTextField();
		b_field.setBounds(120,190,120,25);
		
		hometown = new JLabel("연고지");
		hometown.setBounds(30,230,70,25);
		h_field = new JTextField();
		h_field.setBounds(120,230,120,25);
		
		textpanel.add(name);
		textpanel.add(n_field);
		textpanel.add(age);
		textpanel.add(a_field);
		textpanel.add(kg);
		textpanel.add(k_field);
		textpanel.add(position);
		textpanel.add(p_field);
		textpanel.add(backnum);
		textpanel.add(b_field);
		textpanel.add(hometown);
		textpanel.add(h_field);
				
		this.add(textpanel);
	}
	void Table() {
		String colheader[] = {
				"번","이름","나이","몸무게","포지션","등번호","연고지"
		};
		Object rowdata[][] = {};
		dtm = new DefaultTableModel(null, colheader);
		table = new JTable(dtm);
		jsp = new JScrollPane(table);
		//jsp.setLayout(null);
		jsp.setBounds(5,330,570,200);
		
		this.add(jsp);
	}
	void Button() {
		btnpanel = new JPanel();
		btnpanel.setLayout(null);
		btnpanel.setBounds(0,500,600,100);
		
		bt_main = new JButton("메인메뉴");
		bt_main.setBounds(150,50,130,50);
		bt_main.setForeground(Color.yellow);
		bt_main.setBackground(Color.blue);
		bt_main.addActionListener(this);
		
		bt_add = new JButton("선수추가");
		bt_add.setBounds(300,50,130,50);
		bt_add.setForeground(Color.black);
		bt_add.setBackground(Color.yellow);
		bt_add.addActionListener(this);
		
		btnpanel.add(bt_main);
		btnpanel.add(bt_add);
		
		this.add(btnpanel);
	}
	
	void getListAll(){
		try {
			this.dtm.setRowCount(0);
			
			String quary = "SELECT * FROM player";
			pstmt = cq.conn.prepareStatement(quary);
			rs = pstmt.executeQuery(quary);
			while(rs.next()) {
				int idx = rs.getInt(1);
				String name1 = rs.getString(2);
				String age1 = rs.getString(3);
				String kg1 = rs.getString(4);
				String position1 = rs.getString(5);
				String backnum1 = rs.getString(6);
				String home1 = rs.getString(7);
				
				Object[] rowData = {idx, name1,age1,kg1,position1,backnum1,home1};
				dtm.addRow(rowData);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==bt_main) {
			mn = new Menu();
			dispose();
		}if(e.getSource()==bt_add) {
			String name1 = n_field.getText();
			String age1 = a_field.getText();
			String kg1 = k_field.getText();
			String position1 = p_field.getText();
			String backnum1 = b_field.getText();
			String hometown1 = h_field.getText();
			if(name1.isEmpty()) {
				JOptionPane.showMessageDialog(this, name);
				n_field.requestFocus();
				return;
			}
			if(age1.isEmpty()) {
				JOptionPane.showMessageDialog(this, age);
				a_field.requestFocus();
				return;
			}
			if(kg1.isEmpty()) {
				JOptionPane.showMessageDialog(this, kg);
				k_field.requestFocus();
				return;
			}
			if(position1.isEmpty()) {
				JOptionPane.showMessageDialog(this, position);
				p_field.requestFocus();
				return;
			}
			if(backnum1.isEmpty()) {
				JOptionPane.showMessageDialog(this, backnum);
				b_field.requestFocus();
				return;
			}
			if(hometown1.isEmpty()) {
				JOptionPane.showMessageDialog(this, hometown);
				h_field.requestFocus();
				return;
			}	
				String[] nag = {name1,age1,kg1,position1,backnum1,hometown1};
				
				int result = regist(name1,age1,kg1,position1,backnum1,hometown1);
				if(result != 0) {
					JOptionPane.showMessageDialog(getParent(), "등록성공");
					
				}else {
					JOptionPane.showConfirmDialog(getParent(), "등록실패!");
				}
			}
		}
		
	
	public int regist(String name1, String age1, String kg1, String position1,
			String backnum1, String hometown1) {
		int result = 0;
		String sql = "INSERT INTO player(idx, name, age, kg, position, backnum, hometown) VALUES(?,?,?,?,?,?,?)";
		try {
			pstmt = cq.conn.prepareStatement(sql);
			pstmt.setInt(1, 0);
			pstmt.setString(2, name1);
			pstmt.setString(3, age1);
			pstmt.setString(4, kg1);
			pstmt.setString(5, position1);
			pstmt.setString(6, backnum1);
			pstmt.setString(7, hometown1);
			result = pstmt.executeUpdate();
			
			getListAll();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Inputtable();
	}

}
